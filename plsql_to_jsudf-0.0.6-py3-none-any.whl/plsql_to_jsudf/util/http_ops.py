import base64
import requests
import logging

def get_jwt_token(username: str, password: str, cpaddr: str, logger: logging.Logger):
    # Base64 encode the credentials
    credentials = f"{username}:{password}"
    credentials_base64 = base64.b64encode(credentials.encode()).decode()

    # Set headers for the authentication request
    auth_headers = {
        'Authorization': f'Basic {credentials_base64}',
        'Content-Type': 'application/x-www-form-urlencoded',
    }

    # Payload for the authentication request
    auth_payload = {
        'grant_type': 'password',
        'username': username,
        'password': password,
    }

    # Send request to the sessions endpoint
    auth_url = cpaddr+"/sessions"
    auth_response = requests.post(auth_url, headers=auth_headers, data=auth_payload)

    # Check if authentication was successful
    if auth_response.status_code == 200:
        # Extract JWT token from the response
        jwt_token = auth_response.json().get('jwt')
        return jwt_token
    if auth_response.status_code == 429:
        logger.info("user has sent too many requests in a given amount of time, cause rate-limiting")
        return None
    else:
        logger.info(f"Authentication failed with status code {auth_response.status_code}")
        return None
    

def send_request_with_jwt(jwt_token, cpaddr, orgid, payload: dict, logger: logging.Logger):
    # Set headers for the API request with JWT token
    api_headers = {
        'Authorization': f'Bearer {jwt_token}',
        'Content-Type': 'application/json',
    }

    # API endpoint to send POST requests to
    api_url = cpaddr+"/v2/organizations/"+orgid+"/integrations/iq/openai/chat/completions"

    # Send POST request to the API using the obtained JWT token and JSON payload
    api_response = requests.post(api_url, headers=api_headers, json=payload)
    # Process the API response
    if api_response.status_code == 200:
        # formatted_response = json.dumps(api_response.json(), indent=2)
        return api_response
    else:
        logger.info(f"\nAPI request failed with status code {api_response.status_code}")
        return None