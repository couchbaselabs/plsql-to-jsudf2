from magika import Magika
import logging
from typing import Optional

# input file
def readFile(file_path:str, logger:logging.Logger)->Optional[str]:

    m = Magika()
    try:
        with open(file_path, 'r') as file:
            # Read the entire content of the file
            content = file.read()
            logger.debug(f"File Content:\n{content}")
            
            res = m.identify_bytes(content.encode('utf-8'))
            if res.output.ct_label!="sql":
                print(f"**** Magika says your file conains-> {res.output.ct_label} ****")
                print("this translation is not supported:P")
                return None
            return content

    except FileNotFoundError:
        print(f"The file '{file_path}' was not found.")
        return None
    except Exception as e:
        print(f"An error occurred: {e}")
        return None
