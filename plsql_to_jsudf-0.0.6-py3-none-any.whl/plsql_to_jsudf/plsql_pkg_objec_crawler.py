from .antlrparser.PlSqlParserListener import PlSqlParserListener
from .antlrparser.PlSqlParser import PlSqlParser


def getVal(rule, token_stream):
    start, stop = rule.getSourceInterval()
    val = ""
    for t in range(start, stop+1):
        val+= token_stream.get(t).text

    return val

class PlsqlPkgObjSpecCrawler(PlSqlParserListener):
    pkg_constants = {}
    token_stream = None

    def __init__(self, tokenStream) -> None:
        super().__init__()
        self.token_stream = tokenStream

    # Enter a parse tree produced by PlSqlParser#package_obj_spec.
    def enterPackage_obj_spec(self, ctx:PlSqlParser.Package_obj_specContext):
        # FOR NOW PULLs both variables and constants to inline them
        var_decl = ctx.variable_declaration()
        
        if var_decl is None:
            return
        
        ident = var_decl.identifier()
        ident_val = getVal(ident, self.token_stream)
        val = var_decl.default_value_part()
        val_val = getVal(val, self.token_stream)

        self.pkg_constants[ident_val] = val_val[3:]

        '''
        pkg_decl_val = ""
        start, stop = ctx.getSourceInterval()
        for i in range(start, stop+1):
            pkg_decl_val+=self.token_stream.get(i).text

        if re.search(".+CONSTANT.+:=.+", pkg_decl_val):
            self.pkg_declares.append(pkg_decl_val)
        '''

# if __name__=="__main__":

#     from plsql_ast_crawler import PlsqlAstCrawler
#     from antlrparser.PlSqlLexer import PlSqlLexer
#     from antlrparser.PlSqlParser import PlSqlParser
#     from antlr4 import *

#     content = ""
#     with open("test/plsql/example_cust1.sql", 'r') as file:
#         content = file.read()

#     print(content)
    
#     # astcrawler
#     input_stream = InputStream(content)
#     lexer = PlSqlLexer(input_stream)
#     print("Scanned Tokens")
#     token_stream = CommonTokenStream(lexer)
#     parser = PlSqlParser(token_stream)
#     print("Parsed")
#     tree = parser.sql_script() 
#     print("Parse Tree produced")
#     crawler = PlsqlPkgObjSpecCrawler(token_stream)

#     walker = ParseTreeWalker()
#     walker.walk(crawler, tree)
#     print("AST Crawler Walked the tree to pull out package level declares")

#     print()

#     # for pkg_decl in crawler.pkg_declares:
#     #     print(pkg_decl)   
#     for k,v in crawler.pkg_constants.items():
#         print(k, ":", v)