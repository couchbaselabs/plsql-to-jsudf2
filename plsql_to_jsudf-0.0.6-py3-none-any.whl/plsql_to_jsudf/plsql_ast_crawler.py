from .antlrparser.PlSqlParserListener import PlSqlParserListener
from .antlrparser.PlSqlParser import PlSqlParser

def walk(ctx, s):
    if ctx is None:
        print("ctx is none")
        return s
    
    elif hasattr(ctx, 'getChildren') and callable(getattr(ctx, 'getChildren')):
        ch = ctx.getChildren()
        if ch is None:
            text = ctx.getText()
            if text is not None:
                s = s + text + " "
            return s
        for c in ch:
            s = walk(c,s)
        return s
    
    else:
        text = ctx.getText()
        if text is not None:
            s = s + text + " "
        return s

    

    
    

class PlsqlAstCrawler(PlSqlParserListener):
    content = []
    unitstmtcnt = 0 
    s = ""
    anonymousblockcnt = 0
    pfnames = []
    pftokenindexes = []
    # Enter a parse tree produced by PlSqlParser#create_function_body.
    def enterCreate_function_body(self, ctx:PlSqlParser.Create_function_bodyContext):
        tokenIndex, _ = ctx.CREATE().getSourceInterval()
        self.pftokenindexes.append(tokenIndex)
        
        self.s = ""
        self.s = walk(ctx, self.s)
        self.content.append(self.s)
        self.pfnames.append(ctx.function_name().getText())

    # Enter a parse tree produced by PlSqlParser#function_body.
    def enterFunction_body(self, ctx:PlSqlParser.Function_bodyContext):
        tokenIndex, _ = ctx.FUNCTION().getSourceInterval()
        self.pftokenindexes.append(tokenIndex)

        self.s = ""
        self.s = walk(ctx, self.s)
        self.content.append(self.s)
        self.pfnames.append(ctx.identifier().getText())

    # Enter a parse tree produced by PlSqlParser#procedure_body.
    def enterProcedure_body(self, ctx:PlSqlParser.Procedure_bodyContext):
        tokenIndex, _ = ctx.PROCEDURE().getSourceInterval()
        self.pftokenindexes.append(tokenIndex)
        
        self.s = ""
        self.s = walk(ctx, self.s)
        self.content.append(self.s)
        self.pfnames.append(ctx.identifier().getText())

     # Enter a parse tree produced by PlSqlParser#create_procedure_body.
    def enterCreate_procedure_body(self, ctx:PlSqlParser.Create_procedure_bodyContext):
        tokenIndex, _ = ctx.CREATE().getSourceInterval()
        self.pftokenindexes.append(tokenIndex)
        
        self.s = ""
        self.s = walk(ctx, self.s)
        self.content.append(self.s)
        self.pfnames.append(ctx.procedure_name().getText())


    def enterAnonymous_block(self, ctx:PlSqlParser.Anonymous_blockContext):
        # pull out comments
        if ctx.DECLARE():
            tokenIndex, _ = ctx.DECLARE().getSourceInterval()
            self.pftokenindexes.append(tokenIndex)

        else:
            tokenIndex, _ = ctx.BEGIN().getSourceInterval()
            self.pftokenindexes.append(tokenIndex)
            
        self.s = ""
        self.s = walk(ctx, self.s)
        self.content.append(self.s)
        self.anonymousblockcnt+=1
        self.pfnames.append("anonymousblock"+str(self.anonymousblockcnt))

    # Enter a parse tree produced by PlSqlParser#unit_statement.
    def enterUnit_statement(self, ctx:PlSqlParser.Unit_statementContext):
        self.unitstmtcnt+=1
        
