from .antlrparser.PlSqlParserListener import PlSqlParserListener
from .antlrparser.PlSqlParser import PlSqlParser

def getpartVal(start, stop,token_stream):
    v = ""
    for id in range(start, stop+1):
        tk = token_stream.get(id)
        v+= tk.text
    
    return v

class PlsqlAstStatementBreakingCrawler(PlSqlParserListener):
    stcount = 0
    depth = 0
    validstcount = 0
    parts = []
    vparts = []
    tokenStream = None
    inexception = False
    params = []

    def __init__(self, token_stream) -> None:
        super().__init__()
        self.tokenStream = token_stream

    # Enter a parse tree produced by PlSqlParser#statement.
    def enterStatement(self, ctx:PlSqlParser.StatementContext):        
        if self.inexception==True:
            return
        
        self.stcount+=1
        self.depth+=1

        if self.depth==1:
            self.validstcount+=1 
            # print("stcount:", self.stcount, self.validstcount)
            start, stop = ctx.getSourceInterval()
            # print("start:", start, "stop:", stop)
            self.parts.append((start, stop))

            self.vparts.append(getpartVal(start, stop, self.tokenStream))
            
        else:
            # print("non-valid st at depth:", self.depth)
            # print("stcount:", self.stcount)
            start, stop = ctx.getSourceInterval()
            # print("start:", start, "stop:", stop)

        # print()

    # Exit a parse tree produced by PlSqlParser#statement.
    def exitStatement(self, ctx:PlSqlParser.StatementContext):
        if self.inexception==True:
            return
        
        self.depth-=1

    # Enter a parse tree produced by PlSqlParser#exception_handler.
    def enterException_handler(self, ctx:PlSqlParser.Exception_handlerContext):
        self.inexception = True

    # Exit a parse tree produced by PlSqlParser#exception_handler.
    def exitException_handler(self, ctx:PlSqlParser.Exception_handlerContext):
        self.inexception = False

    # Enter a parse tree produced by PlSqlParser#parameter.
    def enterParameter(self, ctx:PlSqlParser.ParameterContext):
        param = ctx.parameter_name().identifier().id_expression().regular_id().REGULAR_ID().getText()
        # print("param: ", param)
        self.params.append(param)
    

# if __name__ == "__main__":
#     from plsql_ast_crawler import PlsqlAstCrawler
#     from antlrparser.PlSqlLexer import PlSqlLexer
#     from antlrparser.PlSqlParser import PlSqlParser
#     from antlr4 import *
    
#     file = "./test/plsql/largecode"
#     fc = None
#     try:
#         with open(file, 'r') as file:
#             # Read the entire content of the file
#             content = file.read()
#             fc = content
        
#     except FileNotFoundError:
#         print(f"The file '{file}' was not found.")
#         exit(1)
#     except Exception as e:
#         print(f"An error occurred: {e}")
#         exit(1)

#     print(content)

#     # astcrawler
#     input_stream = InputStream(content)
#     lexer = PlSqlLexer(input_stream)
#     print("Scanned Tokens")
#     token_stream = CommonTokenStream(lexer)
#     parser = PlSqlParser(token_stream)
#     print("Parsed")
#     tree = parser.sql_script() 
#     print("Parse Tree produced")
#     crawler = PlsqlAstStatementBreakingCrawler()

#     walker = ParseTreeWalker()
#     walker.walk(crawler, tree)
#     print("AST Crawler Walked the tree to pull out individual statements")

#     print()

#     l = []
#     for st in crawler.parts:
#         print(st[0], st[1]+1)
#         v = ""
#         for id in range(st[0], st[1]+1):
#             tk = token_stream.get(id)
#             v+= tk.text
#         print(v)
#         l.append(v)
#         print()
    

#     import prompt
#     import app
#     import config

#     jwt_token = app.get_jwt_token(config.user, config.password)
#     if jwt_token is None:
#         exit(1)

#     print("\njwt-> ", jwt_token)

    
#     for stmt in l:
#         print("About to translate:\n", stmt)
#         pmpt = prompt.direct_translation_prompt(stmt)
#         apires = app.send_request_with_jwt(jwt_token, pmpt)
#         print("translation:\n")
#         print(apires.text)
#         print("\n")
     