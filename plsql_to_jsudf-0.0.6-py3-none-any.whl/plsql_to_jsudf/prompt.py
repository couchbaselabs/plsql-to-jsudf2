def Do(plsql_script):
    return prompt_v1(plsql_script)

def prompt_v1(plsql_script):
    return  {
        "messages": [
            {
                "role": "user",
                "content": "Can you convert the following PL/SQL to Javascript UDF:"+plsql_script
            }
        ],
        "initMessages": [
            {
                "role": "system",
                "content": "You are a Couchbase AI assistant. You are friendly and helpful like a teacher or an executive assistant. \n Couchbase supports Javascript UDFs. \nIf this is PL/SQL: \nDECLARE x NUMBER := 100; \nBEGIN \nFOR i IN 1..10 LOOP \nIF MOD(i,2) = 0 \nTHEN -- i is even \nINSERT INTO temp \nVALUES (i, x, 'i is even'); \nELSE INSERT INTO temp VALUES (i, x, 'i is odd'); \nEND IF; \nx := x + 100; \nEND LOOP; \nCOMMIT; \nEND; \nthe corresponding Javascript UDF in couchbase would be: \nfunction forloop(){ \nvar x=100; \nvar querybegin=BEGIN WORK; \nquerybegin.close(); \nfor (i=1;i<=10;i++){ \nvar params = [i,x]; \nif (i%2 == 0){ \nvar query= N1QL('INSERT INTO test.testscope.temp VALUES (uuid(),{\"val1\":$1,\"val2\":$2,\"val3\":\"val1 is is even\"})',params); \nquery.close(); \n} \nelse{\n var query= N1QL('INSERT INTO test.testscope.temp VALUES (uuid(),{\"val1\":$1,\"val2\":$2,\"val3\":\"val1 is odd\"})',params); \nquery.close(); \n} \nx = x+100; \n} \nvar querycommit=COMMIT WORK; \nquerycommit.close(); \n} \n\nSimilarly,since cursors are not supported in Couchbase: \nDECLARE CURSOR c1 is \nSELECT ename, empno, sal \nFROM emp ORDER BY sal DESC; -- start with highest paid employee\n my_ename VARCHAR2(10);\n my_empno NUMBER(4);\n my_sal NUMBER(7,2);\n BEGIN OPEN c1; \nFOR i IN 1..5 LOOP \nFETCH c1 INTO my_ename, my_empno, my_sal; \nEXIT WHEN c1%NOTFOUND; \nINSERT INTO emp VALUES (my_sal, my_empno, my_ename); \nCOMMIT; \nEND LOOP;\n CLOSE c1;\n END; \n\nit could be written as: \nfunction alternatetocursor(){\n var querybegin=BEGIN WORK; \nfor (var i = 0;i <5;i++){ \nvar selectquery = SELECT ENAME, EMPNO, SAL from test.testscope.emp order by SAL desc limit 1 offset $i;\n var rs = []; \nfor (const row of selectquery) { \nrs.push(row); \n}\n var e_name=rs[0]['ENAME']; \nvar e_mpno=rs[0]['EMPNO']; \nvar e_sal=rs[0]['SAL']; \nselectquery.close(); \nparams = [e_name,e_mpno,e_sal]; \nvar query= N1QL('insert into test.testscope.temp1 values(uuid(),{\"ENAME\":$1,\"EMPNO\":$2,\"SAL\":$3})',params); \nquery.close(); \n} \nvar query = COMMIT WORK; \nquery.close(); \n}"
            },
             {
                "role": "user",
                "content": "You must follow the below rules:Just do detailed conversion. Do not try to simplify and take shortcuts. Just do as told which is to convert PL/SQL to Couchbase Java script UDF as given in above examples and please do a good job!Do not be lazy."
            }
        ],
        "completionSettings": {
            "model": "gpt-4",
            "temperature": 0,
            "max_tokens": 4096,
            "stream": False
        }
    }

def feedback_prompt_v1(org_prompt, res):
    
    org_prompt["messages"].append({
        "role": "assistant",
        "content": res
    })

    org_prompt["messages"].append({
        "role": "user",
        "content": "Try harder! give me a clean translation"  
    })

    # print("Feedback prompt")
    # print(org_prompt)
    return org_prompt

# statement level translation
def direct_translation_prompt(plsql_statement):
    return {
        "messages": [
            {
                "role": "user",
                "content": "translate the following plsql snippet  to jsudf snippet, don't create a new function, no new input variables assume variables already exit. In other words give me a direct translation in a javascript code block:\n"+plsql_statement
            }
        ],
        "initMessages": [
            {
                "role": "system",
                "content": "You are a Couchbase AI assistant. You are friendly and helpful like a teacher or an executive assistant. \n Couchbase supports Javascript UDFs. \nIf this is PL/SQL: \nDECLARE x NUMBER := 100; \nBEGIN \nFOR i IN 1..10 LOOP \nIF MOD(i,2) = 0 \nTHEN -- i is even \nINSERT INTO temp \nVALUES (i, x, 'i is even'); \nELSE INSERT INTO temp VALUES (i, x, 'i is odd'); \nEND IF; \nx := x + 100; \nEND LOOP; \nCOMMIT; \nEND; \nthe corresponding Javascript UDF in couchbase would be: \nfunction forloop(){ \nvar x=100; \nvar querybegin=BEGIN WORK; \nquerybegin.close(); \nfor (i=1;i<=10;i++){ \nvar params = [i,x]; \nif (i%2 == 0){ \nvar query= N1QL('INSERT INTO test.testscope.temp VALUES (uuid(),{\"val1\":$1,\"val2\":$2,\"val3\":\"val1 is is even\"})',params); \nquery.close(); \n} \nelse{\n var query= N1QL('INSERT INTO test.testscope.temp VALUES (uuid(),{\"val1\":$1,\"val2\":$2,\"val3\":\"val1 is odd\"})',params); \nquery.close(); \n} \nx = x+100; \n} \nvar querycommit=COMMIT WORK; \nquerycommit.close(); \n} \n\nSimilarly,since cursors are not supported in Couchbase: \nDECLARE CURSOR c1 is \nSELECT ename, empno, sal \nFROM emp ORDER BY sal DESC; -- start with highest paid employee\n my_ename VARCHAR2(10);\n my_empno NUMBER(4);\n my_sal NUMBER(7,2);\n BEGIN OPEN c1; \nFOR i IN 1..5 LOOP \nFETCH c1 INTO my_ename, my_empno, my_sal; \nEXIT WHEN c1%NOTFOUND; \nINSERT INTO emp VALUES (my_sal, my_empno, my_ename); \nCOMMIT; \nEND LOOP;\n CLOSE c1;\n END; \n\nit could be written as: \nfunction alternatetocursor(){\n var querybegin=BEGIN WORK; \nfor (var i = 0;i <5;i++){ \nvar selectquery = SELECT ENAME, EMPNO, SAL from test.testscope.emp order by SAL desc limit 1 offset $i;\n var rs = []; \nfor (const row of selectquery) { \nrs.push(row); \n}\n var e_name=rs[0]['ENAME']; \nvar e_mpno=rs[0]['EMPNO']; \nvar e_sal=rs[0]['SAL']; \nselectquery.close(); \nparams = [e_name,e_mpno,e_sal]; \nvar query= N1QL('insert into test.testscope.temp1 values(uuid(),{\"ENAME\":$1,\"EMPNO\":$2,\"SAL\":$3})',params); \nquery.close(); \n} \nvar query = COMMIT WORK; \nquery.close(); \n}"
            }
        ],
        "completionSettings": {
            "model": "gpt-4",
            "temperature": 0,
            "max_tokens": 4096,
            "stream": False
        }
    }

def const_translation_prompt(plsql_decl):
    return {
        "messages": [
            {
                "role": "user",
                "content":"For the following plsql constant declaration\ncan you give me a javascript function with same name as the variable that returns the value that is used to assign in plsql. Nothing else except the function:\n"+plsql_decl
            }
        ],
        "completionSettings": {
            "model": "gpt-4",
            "temperature": 0,
            "max_tokens": 4096,
            "stream": False
        }
    }