import argparse
from . import config
from . import prompt
from magika import Magika
import threading
import time
import requests
import base64
import json
import re
import os
from .plsql_ast_crawler import PlsqlAstCrawler
from .plsql_ast_statement_breaker import PlsqlAstStatementBreakingCrawler
from .plsql_pkg_objec_crawler import PlsqlPkgObjSpecCrawler
from .antlrparser.PlSqlLexer import PlSqlLexer
from .antlrparser.PlSqlParser import PlSqlParser
from antlr4 import *
import logging
from requests.auth import HTTPBasicAuth
from .util.file_ops import *
from .util.http_ops import *

DEBUG = False
OUTPUT_DIR = 'output'
FEEDBACK_KEYWORDS = ["complex"]
AUTO_FEEDBACK_TRAILS = 2


def checkOptionalArgs(args):
    if args.user is not None:
        config.user = args.user
    
    if args.password is not None:
        config.password = args.password

    if args.cpaddr is not None:
        config.cpaddr = args.cpaddr
    
    if args.orgid is not None:
        config.orgid = args.orgid
    
    if args.cbhost is not None:
        config.cbhost = args.cbhost

    if args.cbuser is not None:
        config.cbuser = args.cbuser
    
    if args.cbpassword is not None:
        config.cbpassword = args.cbpassword

    if args.cbport is not None:
        config.cbport = args.cbport

    if args.cblibpath is not None:
        config.cblibpath = args.cblibpath

    
def extract_javascript_content(input_string):
    pattern = r'```javascript([\s\S]*?)```'
    matches = re.findall(pattern, input_string)
    return matches

def get_filename_from_filepath(filepath):
    return os.path.basename(filepath).split('.')[0]

def print_header():
    print("*************************************************")
    print("** Convert a PLSQL package to a JS UDf library **")
    print("*************************************************")

def chatCompletionsReq(jwt_token, plsql_script, logger):
    payload = prompt.Do(plsql_script)

    apires = send_request_with_jwt(jwt_token,config.cpaddr, config.orgid, payload, logger)
    if apires is None:
        return None
    
    if config.controls["feedback"] == True:
        apires = DoFeedBack(payload, apires, jwt_token, logger)
    elif config.controls["autofeedback"] == True:
        apires =DoAutoFeedback(payload, apires, jwt_token, logger)
    
    logger.debug("Apires-> %s", apires.json())
    return apires

def statementchatCompletionReq(jwt_token, statement, logger):
    payload = prompt.direct_translation_prompt(statement)
    apires = send_request_with_jwt(jwt_token, config.cpaddr, config.orgid, payload, logger)
    if apires is None:
        return None

    
    logger.debug(apires.text)
    return apires

def checkcomment(comment):
    if re.match(r'^[\s\n\t\\]+$', comment): 
        return comment
    elif (comment.startswith("/*") and comment.endswith("*/")):
        return comment
    else:
        return "/*\n"+comment+"\n*/\n"

def do_grabconstants(token_stream, tree, walker, logger):
    logger.info("Grabbing Global constants:")
    declcrawler = PlsqlPkgObjSpecCrawler(token_stream)
    walker.walk(declcrawler, tree)

    got_consts = declcrawler.pkg_constants
    logger.info("Number of global constants found: %s", len(got_consts))
    return got_consts

def do_pulloutcomments(crawler, token_stream, logger:logging.Logger):
    c = 0

    func_comments = {}
    for t in crawler.pftokenindexes:
        if DEBUG:
            logger.debug("Hidden tokens for-> %s", crawler.pfnames[c])
        comm = ""
        if token_stream.getHiddenTokensToLeft(t)==None:    
            logger.info("comment for %s:\n%s", crawler.pfnames[c], repr(comm))
            func_comments[crawler.pfnames[c]] = comm
            c+=1
            continue
        for h in token_stream.getHiddenTokensToLeft(t):
            raw_hidden = repr(h.text)
            logger.debug("Hidden token -> %s\nfor c: %s",raw_hidden, c)
            formattedcomment = checkcomment(h.text)
            comm+=formattedcomment

        logger.info("comment for %s:\n%s", crawler.pfnames[c], repr(comm))
        func_comments[crawler.pfnames[c]] = comm
        c+=1

    return func_comments

def doCrawl(jwt_token, plsql_input, file_path, pulloutcomments, logger:logging.Logger):

    # astcrawler
    crawler = PlsqlAstCrawler()

    input_stream = InputStream(plsql_input)
    lexer = PlSqlLexer(input_stream)
    logger.debug("Scanned Tokens")
    token_stream = CommonTokenStream(lexer)
    parser = PlSqlParser(token_stream)
    logger.debug("Parsed")
    tree = parser.sql_script() 
    logger.debug("Parse Tree produced")
    walker = ParseTreeWalker()
    walker.walk(crawler, tree)
    logger.info("AST Crawler Walked the tree to pull out Procedures/Functions/AnonymousBlocks")

    if pulloutcomments:
        logger.info("Scraping out comments to")
        func_comments = do_pulloutcomments(crawler, token_stream, logger)
        logger.info("Pulledout comments")

    logger.info("Crawling done")
    logger.info("Number of Procedures/Functions/Anonymous Blocks found: %s", len(crawler.content))
    logger.info("Listing the names of procedures/functions about to be translated:")
    pfcnt=1
    for name in crawler.pfnames:
        logger.info("%s : %s", pfcnt, name)
        pfcnt+=1

    got_consts = {}
    if config.controls["grabglobalconstants"]:
        got_consts = do_grabconstants(token_stream, tree, walker, logger)
        if len(got_consts)==0:
            logger.info("No Global constants")
        else:
            logger.info("Global Constants found:")

    pfcnt = 0
    for pf in crawler.content:
        if config.controls["grabglobalconstants"] and len(got_consts)>0:
            # # inline any refs to a global const
            # for const_id, const_val in got_consts.items():
            #     logger.info("%s:%s",const_id, const_val)
             
            for const_id, const_val in got_consts.items():
                pf = pf.replace(const_id, const_val)
            logger.info("Global constants replaced for: %s->%s", crawler.pfnames[pfcnt], pfcnt+1)
        
        
        logger.info("About to translate: %s->%s", crawler.pfnames[pfcnt], pfcnt+1)
        apires = chatCompletionsReq(jwt_token, pf, logger)
        
        fmode = (lambda : "w" if pfcnt==0 else "a")()
        
        logger.info("Write API Res to file")
        logger.debug("fmode: %s", fmode)

        if apires is None:
            logger.info("Empty response, so skipping-> %s", crawler.pfnames[pfcnt])
            addtofile("//empty response something went wrong, could be HTTP 429(rate-limited)", file_path, logger, crawler.pfnames[pfcnt], fmode, func_comments)
            continue

        err = apires.json().get("error")
        if err is not None:
            logger.info("translation failed for: %s", crawler.pfnames[pfcnt])
            logger.info("error while translating-> %s", err)
            content = "/* error while translating "+crawler.pfnames[pfcnt]+":"+"\n"+str(err)
            logger.info(err["code"])
            if err["code"] == "context_length_exceeded":
                logger.info("Hit context_length_exceeded error for: %s", crawler.pfnames[pfcnt])

                if config.controls["statement_level"]:
                    logger.info("Trying statement level translation for: %s", crawler.pfnames[pfcnt])
                    addtofile("\n// do statement wise translation\n", file_path, logger, crawler.pfnames[pfcnt], fmode, func_comments)
                    dostatementleveltranslation(pf, file_path, jwt_token, crawler.pfnames[pfcnt], logger)
                else:
                    addtofile(content, file_path, logger, crawler.pfnames[pfcnt], fmode, func_comments)
            else:
                addtofile(content, file_path, logger, crawler.pfnames[pfcnt], fmode, func_comments)
        else:
            content=apires.json().get("choices",{})[0].get('message', None).get('content', None)
            logger.info("translation done: \n%s", content)
            addtofile(content, file_path, logger, crawler.pfnames[pfcnt], fmode, func_comments)
        
        pfcnt+=1

def addtofile(content, file_path, logger, pfname="", mode="a", comments_dict={}):
    # dump to file
    filename = get_filename_from_filepath(file_path)

    output_file_path = OUTPUT_DIR+"/"+filename+".js"

    jscontents = extract_javascript_content(content)
    if len(jscontents)==0:
        content = "/* Couldn't translate to JS-> \n" + "translation failed for:"+ pfname+"\n"+content + "\n*/"
        with open(output_file_path, mode) as ofile:
            # add original comments describing the function.
            ofile.write(comments_dict[pfname])
            ofile.write(content)
        return
    
    logger.debug("js contents:\n %s", jscontents)

    # # dump to file
    # filename = get_filename_from_filepath(file_path)

    # output_file_path = OUTPUT_DIR+"/"+filename+".js"
    with open(output_file_path, mode) as ofile:
        # add original comments describing the function.
        ofile.write(comments_dict[pfname])
        # Write the string to the file
        for js in jscontents:
            ofile.write(js)  
        ofile.write("\n\n")

# Reused for constants with mode as "w"
def addtofileStatement(content, file_path,mode="a"):
    filename = get_filename_from_filepath(file_path)
    output_file_path = OUTPUT_DIR+"/"+filename+".js"

    jscontents = extract_javascript_content(content)

    with open(output_file_path, mode) as ofile:
        for js in jscontents:
            ofile.write(js)
        ofile.write("\n")


def DoFeedBack(payload, apires, jwt_token, logger):
    err = apires.json().get("error")
    if err is not None:
        logger.info("Feedback-Loop-Fail:Request errored out can't provide feedback")
        return apires
    
    content=apires.json().get("choices",{})[0].get('message', None).get('content', None)

    # api
    feedback = False
    for k in FEEDBACK_KEYWORDS:
        if k in content.lower():
            feedback = True
            break
    
    logger.info("Feedback-Loop:")
    if feedback:
        logger.info("translation done: \n", content)
        feedinp = input("Do you want to try again??")
        if feedinp.lower() in ["y", "yes"]:

            feedback_payload = prompt.feedback_prompt_v1(payload, content)
            logger.debug("feedback request sent")
            return send_request_with_jwt(jwt_token, config.cpaddr, config.orgid, feedback_payload, logger)
            
    return apires

def DoAutoFeedback(payload, apires, jwt_token, logger):
    
    err = apires.json().get("error")
    if err is not None:
        logger.info("Request errored out can't provide feedback")
        return apires
    
    content=apires.json().get("choices",{})[0].get('message', None).get('content', None)


     # api
    feedback = False
    for k in FEEDBACK_KEYWORDS:
        if k in content.lower():
            feedback = True
            break
    
    if feedback:
        logger.info("Auto feedback kicked in")
        f=0
        while f<AUTO_FEEDBACK_TRAILS:
            feedback_payload = prompt.feedback_prompt_v1(payload, content)
            if DEBUG==True:
                logger.info("Auto-feedback request-%s sent",f+1)
            apires = send_request_with_jwt(jwt_token,feedback_payload)
            f+=1

            err = apires.json().get("error")
            if err is not None:
                logger.info("Request errored out , no point of auto-feedback")
                return apires
    
            content=apires.json().get("choices",{})[0].get('message', None).get('content', None)

        return apires
    
    return apires

def dostatementleveltranslation(pf, file_path, jwt_token, pf_name, logger):
    logger.info("About to try statement level translation for %s", pf_name)

    if pf.strip()[:9].lower()=="procedure":
        pf = "CREATE "+pf

    if pf.strip()[:8].lower()=="function":
        pf = "CREATE "+pf

    input_stream = InputStream(pf+"\n/")
    lexer = PlSqlLexer(input_stream)
    logger.info("Scanned Tokens for %s", pf_name)
    token_stream = CommonTokenStream(lexer)
    parser = PlSqlParser(token_stream)
    logger.info("Parsed: %s", pf_name)
    tree = parser.sql_script() 
    logger.info("Parse Tree produced for %s", pf_name)
    
    crawler = PlsqlAstStatementBreakingCrawler(token_stream)

    walker = ParseTreeWalker()
    walker.walk(crawler, tree)
    logger.info("AST Crawler Walked the tree to pull out individual statements")

    # function signature
    start_f = '```javascript\nfunction '+pf_name+'(){\n'+'```'
    addtofileStatement(start_f, file_path)

    
    stcount =0
    logger.info("Start translating individual statements")
    for stmtval in crawler.vparts:
        logger.info("About translate stmt: %s", stcount+1)
        logger.debug("stmtval:\n %s", stmtval)
        apires = statementchatCompletionReq(jwt_token, stmtval, logger)
        if apires is None:
            logger.info("Empty response, so skipping statement: %s",stcount+1)
            addtofileStatement('```javascript\n//Skipping statement'+str(stcount+1)+':Empty response\n```', file_path)   
            continue

        err = apires.json().get("error")
        if err is not None:
            logger.info("skipping statement: %s->statement exceeds max tokens limit",stcount+1)
            content = '```javascript\n//Skipping statement'+str(stcount+1)+'\n```'
            addtofileStatement(content, file_path)   
        else:
            content=apires.json().get("choices",{})[0].get('message', None).get('content', None)
            logger.info("statement:%s translation done:%s \n", stcount+1, content)
            addtofileStatement(content, file_path)   
        stcount+=1

    end_f = "```javascript\n}\n\n```"   
    addtofileStatement(end_f, file_path)

    
    
    logger.info("End statement level translation for %s", pf_name)

def createLibrary(libname, logger):
    liburl = config.cbhost +":"+config.cbport+config.cblibpath+libname
    libpath = "output"+"/"+libname+".js"
    
    auth = HTTPBasicAuth(config.cbuser, config.cbpassword)

    logger.debug("url->%s libname->%s libpath->%s", liburl, libname, libpath)

    logger.info("About to create jslibrary from %s", libpath)    
    libcontent = b''
    with open(libpath, "rb") as lfile:
        libcontent = lfile.read()

    liburl = "https://"+liburl
    logger.debug("GJ: new liburl-> %s", liburl)
    response = requests.post(liburl, data=libcontent, auth=auth, verify=False)
    logger.debug("create lib response-status: %s", response.status_code)
    if response.status_code==400:
        logger.info("Error in creating library: %s", response.text)
        logger.info("Resolve error in the file: %s and try creating the library manually", libpath)
    elif response.status_code==200:
        logger.info("successfully created library")
    else:
        logger.info("Unexpected response, status-> %s\n response-text:%s", response.status_code, response.text)


def createFunc(libname, logger):
    
    createLibrary(libname, logger)

    createfuncurl = config.cbhost +":"+config.cbport+config.cbqueryservicepath
    libpath = "output"+"/"+libname+".js"
    auth = (config.cbuser, config.cbpassword)
    logger.debug("Create function url: %s",createfuncurl)

    libcontent = ''
    with open(libpath, "r") as lfile:
        libcontent = lfile.read()

    logger.info("About to create functions from the library")
        
    funcs = re.findall("^\s*function\s*.+\(.*\)", libcontent, re.MULTILINE)
    # if DEBUG==True:
    #     print("Function defs:")
    #     print(funcs)
    logger.debug("Function defs: %s", funcs)
    def createfuncs():
        l = []
        for i in funcs:
            fname = re.search("\s*function\s+(\w+)\(.*\)", i)
            if fname:
                fname = fname.group(1)
                l.append("create or replace "+i.strip()+" LANGUAGE JAVASCRIPT AS \""+ fname+ "\""
                         + " AT \""+libname+"\";")
        return l

    crt = createfuncs()
    createfuncurl = "https://"+createfuncurl
    logger.debug("GJ: new createfuncurl-> %s", createfuncurl)
    logger.info("CREATE FUNCTION statements for the library %s\n%s", libname, crt)
    for c in crt:
        logger.info("About to create function: %s", c.split(" ")[4][:c.split(" ")[4].find("(")])
        response = requests.post(createfuncurl, {"statement": c}, auth=auth)
        logger.debug("response status code-> %s", response.status_code)
        if response.status_code==200:
            logger.info("successfully created function %s",c.split(" ")[4])
        else:
            logger.info("Unexpected response , status->%s text->%s", response.status_code, response.text)


def parseCliArgs():
    parser = argparse.ArgumentParser(description="Script to convert PL/SQL to JsUDF")
    
    # positional cli arguments to be passed 
    parser.add_argument("file", help="path to the plsql script")

    # optional cli arguments -> None for now
    parser.add_argument("-u", "--user", help="username")
    parser.add_argument("-p", "--password", help="password")
    parser.add_argument("-cpaddr", help="url-host for the chat-completions api")
    parser.add_argument("-orgid", help="organisationId in the chat-completions api path")
    parser.add_argument("-cbhost", help="couchbase cluster hostname")
    parser.add_argument("-cbuser", help="couchbase cluster user")
    parser.add_argument("-cbpassword", help="couchbase cluster password")
    parser.add_argument("-cbport", help="query-service port")
    parser.add_argument("-cblibpath", help="path for adding library API")

    return parser.parse_args()

def main():
    # Create logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)  # Set logger level

    # Create file handler and set level to debug
    file_handler = logging.FileHandler('app.log')
    file_handler.setLevel(logging.DEBUG)

    # Create console handler and set level to info
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.DEBUG)

    # Create formatter and add it to the handlers
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)

    # Add handlers to the logger
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
    
    print_header()

    args = parseCliArgs()
    file_path = args.file

    logger.info("Reading input-file: %s", file_path)
    plsql_script = readFile(file_path, logger)
    if plsql_script is None:
        return -1
    

    checkOptionalArgs(args)
    logger.info(f"Config args recieved: {args}")        

    logger.info("Fetching JWT:")
    jwt_token = get_jwt_token(config.user, config.password, config.cpaddr, logger)
    if jwt_token is None:
        return -1
    
    logger.debug(f"JWT: {jwt_token}")



    logger.info("Crawl phase starting, about to pull out individual blocks:")
    # start crawling and pull out functions
    doCrawl(jwt_token, plsql_script, file_path, config.controls['pulloutcomments'], logger)

    # # dump to file
    filename = get_filename_from_filepath(file_path)

    output_file_path = OUTPUT_DIR+"/"+filename+".js" 
    logger.info(f"The translated JsUDF has been successfully written to {output_file_path}.")

    if config.controls["createlib"]==config.createliboptions.ON:
        createLibrary(filename, logger)
    elif config.controls["createlib"]==config.createliboptions.ON_CREATE_FUNC:
        # lib name is file name
        createFunc(filename, logger)
    
    

if __name__=="__main__":
    main()


