from enum import Enum

class createliboptions(Enum):
    OFF = 1
    ON = 2
    ON_CREATE_FUNC = 3

user = "gaurav.jayaraj@couchbase.com"
password = "Gaurav@123"
cpaddr = "https://api.cloud.couchbase.com"
orgid = "7a99d00c-f55b-4b39-bc72-1b4cc68ba894"

cbhost = "127.0.0.1"
cbuser = "Administrator"
cbpassword = "password"
cbport = "18093"
cblibpath = "/evaluator/v1/libraries/"
cbqueryservicepath = "/query/service"
controls = {
    "createlib": createliboptions.ON,
    "feedback": False,
    "autofeedback": False,
    # on exceeding token limit when translating at a procedure level , optionally translate top-level statements one at a time
    "statement_level": True,
    # grab global constants as functions
    "grabglobalconstants": True,
    "pulloutcomments": True
}